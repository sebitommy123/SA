#!/bin/bash
set -e
echo "🚀 Installing SA Shell..."
INSTALL_DIR="$HOME/.local/bin/sa-shell-files"
BIN_DIR="$HOME/.local/bin"
mkdir -p "$BIN_DIR"
if [ -d "$INSTALL_DIR" ]; then
    rm -rf "$INSTALL_DIR"
fi
cp -r "sa-shell-fast" "$INSTALL_DIR"
WRAPPER_SCRIPT="$BIN_DIR/sa-shell"
cat > "$WRAPPER_SCRIPT" << 'WRAPPER_EOF'
#!/bin/bash
exec "$HOME/.local/bin/sa-shell-files/sa-shell-fast" "$@"
WRAPPER_EOF
chmod +x "$WRAPPER_SCRIPT"
echo "✅ Installation complete!"
echo "Usage: sa-shell"
